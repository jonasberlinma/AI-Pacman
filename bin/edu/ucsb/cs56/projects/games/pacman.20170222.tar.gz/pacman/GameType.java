package edu.ucsb.cs56.projects.games.pacman;

enum GameType {
	INTRO, HELP, SINGLEPLAYER, COOPERATIVE, VERSUS, LEADERBOARD
}
