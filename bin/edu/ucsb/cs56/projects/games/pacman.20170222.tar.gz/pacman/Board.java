package edu.ucsb.cs56.projects.games.pacman;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.Timer;

/**
 * Playing field for a Pac-Man arcade game remake that keeps track of all
 * relevant data and handles game logic.
 * <p>
 * The version of the code by Jan Bodnar may be found at
 * http://zetcode.com/tutorials/javagamestutorial/pacman/
 *
 * @author Brian Postma
 * @author Jan Bodnar
 * @author Dario Castellanos
 * @author Brandon Newman
 * @author Daniel Ly
 * @author Deanna Hartsook
 * @author Kateryna Fomenko
 * @author Yuxiang Zhu
 * @author Kelvin Yang
 * @author Joseph Kompella
 * @author Kekoa Sato
 * @version CS56 F16
 */
public class Board {
	/**
	 * 
	 */

	public static final int BLOCKSIZE = 24;
	public static final int NUMBLOCKS = 17;
	public static final int SCRSIZE = NUMBLOCKS * BLOCKSIZE;

	private final int MAX_GHOSTS = 12;
	private final int MAX_SPEED = 6;

	public static int score;
	private LeaderboardGUI leaderBoardGui = new LeaderboardGUI();
	Grid grid;
	GameType gt;
	PacPlayer pacman;
	PacPlayer msPacman;
	Ghost ghost1, ghost2;
	private Character[] pacmen;
	private ArrayList<Ghost> ghosts;
	private int numGhosts = 6;
	int numBoardsCleared = 0;
	private int curSpeed = 3;
	int numPellet;
	private int numPills;

	private Audio beginningAudio;
	private boolean headLess;
	private boolean oneTime;
	public BoardGraphics bg = null;

	Timer timer;

	/**
	 * Constructor for Board object
	 */
	public Board(int loopDelay, boolean headLess, boolean oneTime) {
		this.headLess = headLess;
		this.oneTime = oneTime;

		bg = new BoardGraphics(this, loopDelay);

		grid = new Grid();

		gt = GameType.INTRO;
		grid.levelInit(0);

		pacman = new PacPlayer(8 * BLOCKSIZE, 11 * BLOCKSIZE, PacPlayer.PACMAN, grid);
		msPacman = new PacPlayer(7 * BLOCKSIZE, 11 * BLOCKSIZE, PacPlayer.MSPACMAN, grid);
		ghost1 = new Ghost(8 * BLOCKSIZE, 7 * BLOCKSIZE, 3, Ghost.GHOST1, grid);
		ghost2 = new Ghost(9 * BLOCKSIZE, 7 * BLOCKSIZE, 3, Ghost.GHOST2, grid);

		ghosts = new ArrayList<Ghost>();
		numPills = 4;

		//timer = new Timer(loopDelay, bg);
		//timer.start();

		try {
			this.beginningAudio = new Audio(getClass().getResourceAsStream("assets/audio/beginning.wav"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Main game logic loop
	 *
	 * @param g2d
	 *            a Graphics 2D object
	 */
	public void playGame(Graphics2D g2d) {

		if (!checkAlive()) {
			gameOver();
		} else {
			if (pacman.alive) {
				pacman.move(grid);
				if (bg != null)
					bg.drawPacman(g2d, bg, pacman);
				if (grid.getPillNum() != numPills) {
					for (Ghost g : ghosts) {
						g.edible = true;
						g.edibleTimer = 200;
					}
					numPills = grid.getPillNum();
				}
			}
			switch (gt) {
			case SINGLEPLAYER:
				for (Ghost g : ghosts) {
					g.moveAI(grid, pacmen);
					if (bg != null)
						bg.drawGhost(g2d, bg, g);
				}
				grid.incrementFruit(numBoardsCleared);
				detectCollision(ghosts);
				break;
			case COOPERATIVE:
				if (msPacman.alive) {
					msPacman.move(grid);
					if (bg != null)
						bg.drawPacman(g2d, bg, msPacman);
				}
				for (Ghost g : ghosts) {
					g.moveAI(grid, pacmen);
					if (bg != null)
						bg.drawGhost(g2d, bg, g);
				}
				grid.incrementFruit(numBoardsCleared);
				detectCollision(ghosts);
				break;
			case VERSUS:
				for (Ghost g : ghosts) {
					g.move(grid);
					if (bg != null)
						bg.drawGhost(g2d, bg, g);
				}

				if (score >= numPellet) {
					score = 0;
					numBoardsCleared++;
					grid.levelInit(numBoardsCleared);
					levelContinue();

				}
				grid.incrementFruit(numBoardsCleared);
				detectCollision(ghosts);
				break;
			case HELP:
				break;
			case INTRO:
				break;
			case LEADERBOARD:
				break;
			default:
				break;
			}
			if (grid.checkMaze()) {
				score += 50;
				numBoardsCleared++;

				numGhosts = (numGhosts + 1) % MAX_GHOSTS;
				curSpeed = (curSpeed + 1) % MAX_SPEED;
				grid.levelInit(numBoardsCleared);
				levelContinue();
			}
		}
	}

	/**
	 * End the game if remaining lives reaches 0.
	 */
	public void gameOver() {
		if (!oneTime) {
			if (gt != GameType.VERSUS) {
				if (score > 1)
					bg.sl.writeScore(score);
			}
			Date d = new Date();
			if (gt == GameType.SINGLEPLAYER)
				leaderBoardGui.showEndGameScreen(Board.score, d, 1);
			else if (gt == GameType.COOPERATIVE)
				leaderBoardGui.showEndGameScreen(Board.score, d, 2);
			else if (gt == GameType.VERSUS)
				leaderBoardGui.showEndGameScreen(Board.score, d, 3);
			gt = GameType.INTRO;
		} else {
			gameInit();
			gt = GameType.SINGLEPLAYER;
		}

		numBoardsCleared = 0;
		grid.levelInit(0);

	}

	/**
	 * Detects when ghosts and pacman collide
	 *
	 * @param ghosts
	 *            An array of Ghost
	 */
	public void detectCollision(ArrayList<Ghost> ghosts) {
		for (Character pacman : pacmen) {
			for (Ghost ghost : ghosts) {
				if ((Math.abs(pacman.x - ghost.x) < 20 && Math.abs(pacman.y - ghost.y) < 20) && ghost.edible == false)
					pacman.death();

				if ((Math.abs(pacman.x - ghost.x) < 20 && Math.abs(pacman.y - ghost.y) < 20) && ghost.edible == true) {
					ghost.death();
					score += 40;
				}
			}
		}
	}

	/**
	 * Returns true if any pacman is alive, returns false if they are all dead
	 *
	 * @return true if any surviving, false if all dead
	 */
	public boolean checkAlive() {
		for (Character pacman : pacmen)
			if (pacman.alive)
				return true;
		return false;
	}

	/**
	 * Initialize game variables
	 */
	public void gameInit() {
		grid.levelInit(numBoardsCleared);
		levelContinue();
		score = 0;
		numGhosts = 6;
		curSpeed = 3;
		numPills = 4;

		try {
			this.beginningAudio.play();
		} catch (Exception e) {
			e.printStackTrace();
		}

		switch (gt) {
		case SINGLEPLAYER:
			pacmen = new Character[1];
			pacmen[0] = pacman;
			pacman.reset();
			break;
		case COOPERATIVE:
			pacmen = new Character[2];
			pacmen[0] = pacman;
			pacmen[1] = msPacman;
			pacman.reset();
			msPacman.reset();
			break;
		case VERSUS:
			pacmen = new Character[1];
			pacmen[0] = pacman;
			pacman.reset();
			break;
		default:
			break;
		}
	}

	/**
	 * Initialize Pacman and ghost position/direction
	 */
	public void levelContinue() {
		numPellet = grid.getPelletNum() + grid.getPillNum();
		numPills = grid.getPillNum();
		ghosts.clear();
		if (gt == GameType.VERSUS) {
			ghosts.add(ghost1);
			ghosts.add(ghost2);
		} else {
			for (int i = 0; i < numGhosts; i++) {
				int random = (int) (Math.random() * curSpeed) + 1;
				ghosts.add(new Ghost((i + 6) * BLOCKSIZE, 2 * BLOCKSIZE, random, i % 2));
			}
		}
		switch (gt) {
		case SINGLEPLAYER:
			pacman.resetPos();
			break;
		case COOPERATIVE:
			pacman.resetPos();
			msPacman.resetPos();
			break;
		case VERSUS:
			pacman.resetPos();
			for (Character ghost : ghosts) {
				ghost.resetPos();
				if (numBoardsCleared == 3)
					ghost.speed = MAX_SPEED;
			}
			break;
		default:
			break;
		}
	}

	/**
	 * Paint graphics onto screen
	 *
	 * @param g
	 *            a Graphics object
	 */
	public void boardPaint(Graphics g) {

		Graphics2D g2d = (Graphics2D) g;

		grid.drawMaze(g2d);
		bg.drawScore(g, gt, this);
		switch (gt) {
		case INTRO:
			bg.showIntroScreen(g);
			break;
		case HELP:
			bg.showHelpScreen(g);
			break;
		default:
			playGame(g2d);
		}

		if (!bg.timer.isRunning())
			bg.showPauseScreen(g);

		Toolkit.getDefaultToolkit().sync();
		g.dispose();
	}

	/**
	 * Calls the leaderboards main method with the command line arguments
	 *
	 * @param args
	 *            - represents the command line arguments
	 */
	public void callLeaderboardMain(String args) {
		String[] files = { "pacmanleaderboardsingle.ser", "pacmanleaderboardcoop.ser", "pacmanleaderboardversus.ser" };
		leaderBoardGui.setLeaderBoardFileName(files);
	}

}
